<?php
$con = new mysqli("localhost","root","","sewa_sepeda");
$query="DELETE FROM data_sepeda WHERE `data_sepeda`.`nama` = '".$_POST['nama']."'";
$result = $con->query($query);
if ($result) {
   echo "Data Berhasil Di Hapus";
}else{
    echo "false";
}
?>