<?php
$con = new mysqli("localhost","root","","sewa_sepeda");
$query = "INSERT INTO `data_sepeda` (`nama`, `jenis`, `harga`, `stok`) VALUES ($_POST['nama']."', '".$_POST['jenis']."', '".$_POST['harga']."', '".$_POST['stok']."');";
$result = $con->query($query);
if ($result) {
   echo "Data Berhasil DiTambahkan";
}else{
    echo "false";
}
?>