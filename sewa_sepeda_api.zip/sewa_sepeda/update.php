<?php
$con = new mysqli("localhost","root","","sewaa_sepeda");
$query="UPDATE `data_sepeda` SET `jenis` = '".$_POST['jenis']."', `harga` = '".$_POST['harga']."' WHERE `data_sepeda`.`nama` = '".$_POST['nama']."'";
$result = $con->query($query);
if ($result) {
   echo "Data Berhasil DiUpdate";
}else{
    echo "false";
}
?>