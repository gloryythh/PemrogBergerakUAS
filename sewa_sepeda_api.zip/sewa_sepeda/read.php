<?php 
$con = new mysqli("localhost","root","","sewa_sepeda");
$query = "Select * from data_sepeda";
$result = $con->query($query);
if ($result) {
    $data_sepeda = array();
    while($row = $result->fetch_assoc()){
        $data_sepeda[] = $row;
    }
    $json_response = json_encode($data_sepeda);
    echo $json_response;
}else{
    echo "Error". $con->error;
}
$con->close();
?>