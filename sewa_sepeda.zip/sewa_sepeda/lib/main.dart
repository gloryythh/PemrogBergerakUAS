import 'package:mysql1/mysql1.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();

  factory DatabaseHelper() => _instance;

  Database _database;

  Future<Database> get database async {
    if (_database == null) {
      _database = await openDatabase(
        'sewaa_sepeda.db',
        onCreate: (db, version) async {
          await db.execute(
              'CREATE TABLE data_sepeda (id INTEGER PRIMARY KEY AUTOINCREMENT, nama_sepeda TEXT, merek TEXT, harga INTEGER)');
          await db.execute(
              'CREATE TABLE data_peminjam (id INTEGER PRIMARY KEY AUTOINCREMENT, nama_peminjam TEXT, alamat TEXT, no_telp TEXT, tanggal_peminjaman TEXT, tanggal_pengembalian TEXT, id_sepeda INTEGER)');
        },
        version: 1,
      );
    }
    return _database;
  }

  // Menambahkan data ke tabel data_sepeda
  Future<void> addSepeda(Sepeda sepeda) async {
    final db = await database;
    await db.insert('data_sepeda', sepeda.toMap());
  }

  // Menambahkan data ke tabel data_peminjam
  Future<void> addPeminjam(Peminjam peminjam) async {
    final db = await database;
    await db.insert('data_peminjam', peminjam.toMap());
  }

  // Mendapatkan semua data dari tabel data_sepeda
  Future<List<Sepeda>> getAllSepeda() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('data_sepeda');
    return List.generate(maps.length, (i) {
      return Sepeda(
        id: maps[i]['id'],
        namaSepeda: maps[i]['nama_sepeda'],
        merek: maps[i]['merek'],
        harga: maps[i]['harga'],
      );
    });
  }

  // Mendapatkan semua data dari tabel data_peminjam
  Future<List<Peminjam>> getAllPeminjam() async {
    final db = await database;import 'dart:convert';

import "package:flutter/material.dart";
import 'package:http/http.dart' as http;

class ReadScreen extends StatefulWidget {
  const ReadScreen({super.key});

  @override
  State<ReadScreen> createState() => ReadScreenState();
}

class _ReadScreenState extends State<ReadScreen> {
  List sepeda = []
  Future<void> ambildata() async {
    final response = await http.get(Uri.parse("http://192.168.1.4/sewa_sepeda/read.php"));
    if (response.statusCode == 200) {
      setState(() {
        data_sepeda = json.decode(response.body);
        print(data_sepeda);
      });
    }else{
      print("gagal mendapatkan data");
    }
  }
  @override
  void initState(){
    super.initState();
    ambildata();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Sewa Sepeda"),
        backgroundColor: Colors.lightGreen,
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.height,
        child: ListView.builder(itemCount: data_sepeda.length, itemBuilder: (BuildContext context, index){
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container
          decoration: BoxDecoration,
          border: Border.all(width: 1)
          child: ListTile(
            title: Text(data_sepeda[index]['nama']),
            subtitle: Text("stok"),
          ),
          )
        ),
        }
      ),
      floatingActionButton: FloatingActionButton(
          backgroundColor: const Color.fromARGB(255, 169, 223, 171),
          child: Icon(Icon.adds),
          onPressed: () {}),
    );
  }
}

    final List<Map<String, dynamic>> maps = await db.query('data_peminjam');
    return List.generate(maps.length, (i) {
      return Peminjam(
        id: maps[i]['id'],
        namaPeminjam: maps[i]['nama_peminjam'],
        alamat: maps[i]['alamat'],
        noTelp: maps[i]['no_telp'],
        tanggalPeminjaman: maps[i]['tanggal_peminjaman'],
        tanggalPengembalian: maps[i]['tanggal_pengembalian'],
        idSepeda: maps[i]['id_sepeda'],
      );
    });
  }

  // Menghapus data dari tabel data_sepeda
  Future<void> deleteSepeda(int id) async {
    final db = await database;
    await db.delete('data_sepeda', where: 'id = ?', whereArgs: [id]);
  }

  // Menghapus data dari tabel data_peminjam
  Future<void> deletePeminjam(int id) async {
    final db = await database;
    await db.delete('data_peminjam', where: 'id = ?', whereArgs: [id]);
  }
}

class Sepeda {
  final int id;
  final String namaSepeda;
  final String merek;
  final int harga;

  Sepeda({this.id, this.namaSepeda, this.merek, this.harga});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nama_
