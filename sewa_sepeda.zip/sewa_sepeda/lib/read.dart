import 'dart:convert';

import "package:flutter/material.dart";
import 'package:http/http.dart' as http;

class ReadScreen extends StatefulWidget {
  const ReadScreen({super.key});

  @override
  State<ReadScreen> createState() => ReadScreenState();
}

class _ReadScreenState extends State<ReadScreen> {
  List sepeda = []
  Future<void> ambildata() async {
    final response = await http.get(Uri.parse("http://192.168.1.4/sewa_sepeda/read.php"));
    if (response.statusCode == 200) {
      setState(() {
        data_sepeda = json.decode(response.body);
        print(data_sepeda);
      });
    }else{
      print("gagal mendapatkan data");
    }
  }
  @override
  void initState(){
    super.initState();
    ambildata();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Sewa Sepeda"),
        backgroundColor: Colors.lightGreen,
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.height,
        child: ListView.builder(itemCount: data_sepeda.length, itemBuilder: (BuildContext context, index){
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container
          decoration: BoxDecoration,
          border: Border.all(width: 1)
          child: ListTile(
            title: Text(data_sepeda[index]['nama']),
            subtitle: Text("stok"),
          ),
          )
        ),
        }
      ),
      floatingActionButton: FloatingActionButton(
          backgroundColor: const Color.fromARGB(255, 169, 223, 171),
          child: Icon(Icon.adds),
          onPressed: () {}),
    );
  }
}
